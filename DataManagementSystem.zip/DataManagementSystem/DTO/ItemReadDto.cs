﻿namespace DataManagementSystem.DTO
{
    // ItemReadDto is used for transferring item data back to the client.
    // This DTO is typically used when sending data retrieved from the database to the user.
    public class ItemReadDto
    {
        // Unique identifier for the item.
        public int Id { get; set; }

        // The name of the item.
        public string Name { get; set; }

        // A brief description of the item.
        public string Description { get; set; }

        // The price of the item, represented as a decimal.
        public decimal Price { get; set; }

        // The URL of the item's image.
        // This should be a path or a URL pointing to where the image is stored.
        public string ImageUrl { get; set; }

        // Additional properties can be added here to provide more details about the item.
        // For example, details about the category or retailer can be included if necessary.
        // These could be implemented as additional properties or foreign key references.
    }
}
