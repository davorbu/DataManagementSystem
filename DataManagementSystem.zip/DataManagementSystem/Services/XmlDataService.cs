﻿using System.Xml;
using System.Xml.Linq;
using DataManagementSystem.Models;

namespace DataManagementSystem.Services
{
    public class XmlDataService
    {
        public List<Item> ParseItemsFromXml(Stream xmlStream)
        {
            XDocument xDocument;
            try
            {
                xDocument = XDocument.Load(xmlStream);
            }
            catch (XmlException ex)
            {
                throw new InvalidOperationException("Invalid XML format.", ex);
            }

            var items = xDocument.Descendants("Item")
                .Select(x => {
                    // Secure value retrieval and handling of potential parsing issues
                    var priceString = x.Element("Price")?.Value ?? "0";
                    if (!decimal.TryParse(priceString, out decimal price))
                    {
                        throw new InvalidOperationException($"Invalid price format for item: {x.Element("Name")?.Value}");
                    }

                    // Basic checks and parsing for RetailerId and CategoryId
                    var retailerIdString = x.Element("RetailerId")?.Value ?? "0";
                    if (!int.TryParse(retailerIdString, out int retailerId))
                    {
                        throw new InvalidOperationException($"Invalid retailer ID format for item: {x.Element("Name")?.Value}");
                    }

                    var categoryIdString = x.Element("CategoryId")?.Value ?? "0";
                    if (!int.TryParse(categoryIdString, out int categoryId))
                    {
                        throw new InvalidOperationException($"Invalid category ID format for item: {x.Element("Name")?.Value}");
                    }

                    // Creating and returning a new Item object
                    return new Item
                    {
                        Name = x.Element("Name")?.Value,
                        Description = x.Element("Description")?.Value,
                        Price = price,
                        ImageUrl = x.Element("ImageUrl")?.Value,
                        RetailerId = retailerId,
                        CategoryId = categoryId
                    };
                }).ToList();

            return items;
        }
    }
}
