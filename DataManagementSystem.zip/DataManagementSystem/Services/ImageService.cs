﻿namespace DataManagementSystem.Services
{
    using System;
    using System.IO;
    using System.Net.Http;
    using System.Threading.Tasks;


    public class ImageDownloadException : Exception
    {
        public ImageDownloadException(string message) : base(message)
        {
        }

        public ImageDownloadException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }

    // ImageService is responsible for downloading images and storing them locally.
    // It uses IHttpClientFactory for making HTTP requests.
    public class ImageService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly string _imageSavePath;

        public ImageService(IHttpClientFactory httpClientFactory, string imageSavePath)
        {
            _httpClientFactory = httpClientFactory;
            _imageSavePath = imageSavePath;
        }

        public async Task<string> DownloadImageAsync(string imageUrl)
        {
            try
            {
                var fileName = Path.GetFileName(imageUrl);
                var localPath = Path.Combine(_imageSavePath, fileName);

                using var client = _httpClientFactory.CreateClient();
                var response = await client.GetAsync(imageUrl);

                if (!response.IsSuccessStatusCode)
                {
                    throw new ImageDownloadException($"Failed to download image from {imageUrl}. Response status: {response.StatusCode}.");
                }

                using var stream = await response.Content.ReadAsStreamAsync();
                using var fileStream = new FileStream(localPath, FileMode.Create, FileAccess.Write);
                await stream.CopyToAsync(fileStream);

                return localPath;
            }
            catch (Exception ex)
            {
                throw new ImageDownloadException($"An error occurred while downloading the image from {imageUrl}.", ex);
            }
        }
    }

}
