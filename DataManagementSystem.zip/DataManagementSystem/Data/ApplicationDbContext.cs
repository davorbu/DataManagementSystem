﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using DataManagementSystem.Models;
using Microsoft.AspNetCore.Identity;

namespace DataManagementSystem.Data
{
    public class ApplicationDbContext : IdentityDbContext<IdentityUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Retailer> Retailers { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Item> Items { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Konfiguracija indeksa za CategoryId i RetailerId unutar Item entiteta
            modelBuilder.Entity<Item>()
                .HasIndex(i => i.CategoryId)
                .HasDatabaseName("IDX_CategoryId");

            modelBuilder.Entity<Item>()
                .HasIndex(i => i.RetailerId)
                .HasDatabaseName("IDX_RetailerId");

            // Osiguravanje da je ime kategorije jedinstveno
            modelBuilder.Entity<Category>()
                .HasIndex(c => c.Name)
                .IsUnique()
                .HasDatabaseName("IDX_CategoryName_Unique");

            // Primena ograničenja da ime Retailera ne može biti null
            modelBuilder.Entity<Retailer>()
                .Property(r => r.Name)
                .IsRequired();
        }
    }
}
