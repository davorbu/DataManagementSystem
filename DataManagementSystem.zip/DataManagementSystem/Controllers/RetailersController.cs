﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using DataManagementSystem.Data;
using DataManagementSystem.Models;
using Microsoft.EntityFrameworkCore;

[Route("api/[controller]")]
[ApiController]
public class RetailersController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public RetailersController(ApplicationDbContext context)
    {
        _context = context;
    }

    // POST: api/Retailers
    // This endpoint adds a new retailer with the specified name.
    [HttpPost]
    [Authorize(Roles = "Admin,Employee")]
    public async Task<ActionResult<Retailer>> AddRetailer([FromBody] string name)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            return BadRequest("Retailer name cannot be empty.");
        }

        var retailer = new Retailer { Name = name };
        _context.Retailers.Add(retailer);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetRetailerById), new { id = retailer.Id }, retailer);
    }

    // PUT: api/Retailers/5
    // This endpoint updates the name of the retailer with the given ID.
    [HttpPut("{id}")]
    [Authorize(Roles = "Admin,Employee")]
    public async Task<IActionResult> UpdateRetailer(int id, [FromBody] string name)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            return BadRequest("Retailer name cannot be empty.");
        }

        var retailer = await _context.Retailers.FindAsync(id);
        if (retailer == null)
        {
            return NotFound("Retailer not found.");
        }

        retailer.Name = name;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    // GET: api/Retailers/5
    // This endpoint retrieves a retailer by its ID.
    [HttpGet("{id}")]
    [Authorize(Roles = "Admin,Employee,User")]
    public async Task<ActionResult<Retailer>> GetRetailerById(int id)
    {
        var retailer = await _context.Retailers.FindAsync(id);
        if (retailer == null)
        {
            return NotFound();
        }

        return retailer;
    }

    // GET: api/Retailers
    // This endpoint retrieves all retailers.
    [HttpGet]
   [Authorize(Roles = "Admin,Employee,User")]
    public async Task<ActionResult<IEnumerable<Retailer>>> GetAllRetailers()
    {
        return await _context.Retailers.ToListAsync();
    }

    // DELETE: api/Retailers/5
    // This endpoint deletes a retailer by its ID.
    [HttpDelete("{id}")]
    [Authorize(Roles = "Admin,Employee")]
    public async Task<IActionResult> DeleteRetailer(int id)
    {
        var retailer = await _context.Retailers.FindAsync(id);
        if (retailer == null)
        {
            return NotFound("Retailer not found.");
        }

        _context.Retailers.Remove(retailer);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}
