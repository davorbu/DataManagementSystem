﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using DataManagementSystem.Data;
using DataManagementSystem.Models;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using DataManagementSystem.Services;
using DataManagementSystem.DTO;
using System.Xml;

[Route("api/[controller]")]
[ApiController]
public class ItemsController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly XmlDataService _xmlDataService;
    private readonly ImageService _imageService;
    private readonly ILogger<ItemsController> _logger;

    // Constructor for ItemsController
    // Dependencies are injected via constructor
    public ItemsController(ApplicationDbContext context, XmlDataService xmlDataService, ImageService imageService, ILogger<ItemsController> logger)
    {
        _context = context;
        _xmlDataService = xmlDataService;
        _imageService = imageService;
        _logger = logger;
    }

    // GET: api/Items
    // Retrieves all items with optional pagination
    [HttpGet]
    [Authorize(Roles = "Admin,Employee,User")] // Accessible by all roles
    public async Task<ActionResult<IEnumerable<ItemReadDto>>> GetAllItems(int? pageNumber = 1, int? countPerPage = 8)
    {
        int currentPageNumber = pageNumber ?? 1;
        int currentPageSize = countPerPage ?? 8;

        var items = await _context.Items
            .Include(i => i.Retailer)
            .Include(i => i.Category)
            .Skip((currentPageNumber - 1) * currentPageSize)
            .Take(currentPageSize)
            .Select(i => new ItemReadDto
            {
                Id = i.Id,
                Name = i.Name,
                Description = i.Description,
                Price = i.Price,
                ImageUrl = i.ImageUrl
            })
            .ToListAsync();

        return items;
    }

    // GET: api/Items/5
    // Retrieves a specific item by id
    [HttpGet("{id}")]
    [Authorize(Roles = "Admin,Employee,User")] // Accessible by all roles
    public async Task<ActionResult<ItemReadDto>> GetItemById(int id)
    {
        var item = await _context.Items
            .Include(i => i.Retailer)
            .Include(i => i.Category)
            .Where(i => i.Id == id)
            .Select(i => new ItemReadDto
            {
                Id = i.Id,
                Name = i.Name,
                Description = i.Description,
                Price = i.Price,
                ImageUrl = i.ImageUrl
            })
            .FirstOrDefaultAsync();

        if (item == null)
        {
            return NotFound();
        }

        return item;
    }

    // POST: api/Items
    // Adds a new item to the database
    [HttpPost]
    [Authorize(Roles = "Admin,Employee")]
    public async Task<ActionResult<ItemReadDto>> AddItem(ItemCreateDto itemCreateDto)
    {
        try
        {
            var localImagePath = await _imageService.DownloadImageAsync(itemCreateDto.ImageUrl);
            var item = new Item
            {
                Name = itemCreateDto.Name,
                Description = itemCreateDto.Description,
                Price = itemCreateDto.Price,
                ImageUrl = localImagePath,
                RetailerId = itemCreateDto.RetailerId,
                CategoryId = itemCreateDto.CategoryId
            };

            _context.Items.Add(item);
            await _context.SaveChangesAsync();

            var itemReadDto = new ItemReadDto
            {
                Id = item.Id,
                Name = item.Name,
                Description = item.Description,
                Price = item.Price,
                ImageUrl = item.ImageUrl
            };

            return CreatedAtAction(nameof(GetItemById), new { id = item.Id }, itemReadDto);
        }
        catch (ImageDownloadException ex)
        {
            // Log the error and return an appropriate response
            _logger.LogError(ex, "Failed to download image.");
            return StatusCode(StatusCodes.Status500InternalServerError, "Error downloading image.");
        }
    }


    // PUT: api/Items/5
    // Updates an existing item in the database
    [HttpPut("{id}")]
    [Authorize(Roles = "Admin,Employee")] // Accessible by Admin and Employee roles
    public async Task<IActionResult> UpdateItem(int id, ItemCreateDto itemUpdateDto)
    {
        var item = await _context.Items.FindAsync(id);
        if (item == null)
        {
            return NotFound();
        }

        // Updating item details based on the provided DTO
        item.Name = itemUpdateDto.Name;
        item.Description = itemUpdateDto.Description;
        item.Price = itemUpdateDto.Price;
        item.ImageUrl = itemUpdateDto.ImageUrl; // Assumes image URL update is required
        item.RetailerId = itemUpdateDto.RetailerId;
        item.CategoryId = itemUpdateDto.CategoryId;

        _context.Entry(item).State = EntityState.Modified;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    // DELETE: api/Items/5
    // Deletes a specific item from the database
    [HttpDelete("{id}")]
    [Authorize(Roles = "Admin,Employee")] // Accessible by Admin and Employee roles
    public async Task<IActionResult> DeleteItem(int id)
    {
        var item = await _context.Items.FindAsync(id);
        if (item == null)
        {
            return NotFound();
        }

        _context.Items.Remove(item);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    // Additional functionality to load data from XML
    [HttpPost("LoadDataFromXml")]
    public async Task<IActionResult> LoadDataFromXml(IFormFile xmlFile)
    {
        if (xmlFile == null || xmlFile.Length == 0)
        {
            return BadRequest("XML file is empty or not provided.");
        }

        try
        {
            using var stream = xmlFile.OpenReadStream();
            var items = _xmlDataService.ParseItemsFromXml(stream);
            foreach (var item in items)
            {
                var localImagePath = await _imageService.DownloadImageAsync(item.ImageUrl);
                item.ImageUrl = localImagePath;
                _context.Items.Add(item);
            }
            await _context.SaveChangesAsync();
            return Ok(new { message = "Data loaded successfully from XML." });
        }
        catch (XmlException ex)
        {
            // Logging the exception and returning an appropriate response
            return BadRequest(new { message = "Error processing XML file: " + ex.Message });
        }
    }

    // Checks if an item exists in the database by ID
    private bool ItemExists(int id)
    {
        return _context.Items.Any(e => e.Id == id);
    }
}
