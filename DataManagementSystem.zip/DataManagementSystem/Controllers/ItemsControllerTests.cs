﻿using DataManagementSystem.Data;
using DataManagementSystem.DTO;
using DataManagementSystem.Models;
using DataManagementSystem.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using Xunit;

namespace DataManagementSystem.Controllers
{
    public class ItemsControllerTests
    {
        [Fact]
        public async Task GetAllItems_ReturnsListOfItems()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .Options;

            using var context = new ApplicationDbContext(options);
            var controller = new ItemsController(context, null, null, null);

            // Add test data to the in-memory database
            context.Items.Add(new Item { Id = 1, Name = "Item 1" });
            context.Items.Add(new Item { Id = 2, Name = "Item 2" });
            context.SaveChanges();

            // Act
            var result = await controller.GetAllItems();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var items = Assert.IsAssignableFrom<IEnumerable<ItemReadDto>>(okResult.Value);
            Assert.Equal(2, items.Count());
        }

        [Fact]
        public async Task GetItemById_ReturnsItem()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .Options;

            using var context = new ApplicationDbContext(options);
            var controller = new ItemsController(context, null, null, null);

            // Add test data to the in-memory database
            context.Items.Add(new Item { Id = 1, Name = "Item 1" });
            context.SaveChanges();

            // Act
            var result = await controller.GetItemById(1);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var item = Assert.IsType<ItemReadDto>(okResult.Value);
            Assert.Equal("Item 1", item.Name);
        }


        [Fact]
        public async Task AddItem_CreatesNewItem_ReturnsCreatedAtActionResult()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabaseForAdd")
                .Options;

            using var context = new ApplicationDbContext(options);
            var mockXmlDataService = new Mock<XmlDataService>();
            var mockImageService = new Mock<ImageService>();
            var mockLogger = new Mock<ILogger<ItemsController>>();
            var controller = new ItemsController(context, mockXmlDataService.Object, mockImageService.Object, mockLogger.Object);

            var newItem = new ItemCreateDto { Name = "New Item", Description = "New Description", Price = 100, ImageUrl = "http://example.com/image.jpg" };

            // Act
            var result = await controller.AddItem(newItem);

            // Assert
            var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result.Result);
            var itemReadDto = Assert.IsType<ItemReadDto>(createdAtActionResult.Value);
            Assert.Equal(newItem.Name, itemReadDto.Name);
            Assert.Equal(newItem.Description, itemReadDto.Description);
            Assert.Equal(newItem.Price, itemReadDto.Price);
            Assert.NotNull(itemReadDto.ImageUrl);
        }

        [Fact]
        public async Task UpdateItem_ItemExists_ReturnsNoContentResult()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabaseForUpdate")
                .Options;

            using var context = new ApplicationDbContext(options);
            var controller = new ItemsController(context, null, null, null);

            var testItem = new Item { Id = 1, Name = "Original Item", Description = "Original Description", Price = 50, ImageUrl = "http://example.com/original.jpg" };
            context.Items.Add(testItem);
            await context.SaveChangesAsync();

            var updatedItem = new ItemCreateDto { Name = "Updated Item", Description = "Updated Description", Price = 100, ImageUrl = "http://example.com/updated.jpg" };

            // Act
            var result = await controller.UpdateItem(testItem.Id, updatedItem);

            // Assert
            Assert.IsType<NoContentResult>(result);
        }


        [Fact]
        public async Task DeleteItem_ItemExists_ReturnsNoContentResult()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabaseForDelete")
                .Options;

            using var context = new ApplicationDbContext(options);
            var controller = new ItemsController(context, null, null, null);

            var testItem = new Item { Id = 1, Name = "Item to Delete", Description = "Description", Price = 50, ImageUrl = "http://example.com/delete.jpg" };
            context.Items.Add(testItem);
            await context.SaveChangesAsync();

            // Act
            var result = await controller.DeleteItem(testItem.Id);

            // Assert
            Assert.IsType<NoContentResult>(result);
            Assert.False(context.Items.Any(i => i.Id == testItem.Id)); // Dodatno proveravamo da li je item zaista obrisan
        }


    }
}
