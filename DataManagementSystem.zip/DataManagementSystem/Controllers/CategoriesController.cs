﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using DataManagementSystem.Data;
using DataManagementSystem.Models;
using Microsoft.EntityFrameworkCore;

[Route("api/[controller]")]
[ApiController]
public class CategoriesController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public CategoriesController(ApplicationDbContext context)
    {
        _context = context;
    }

    // POST: api/Categories
    // This endpoint adds a new category with the specified name.
    [HttpPost]
    [Authorize(Roles = "Admin,Employee")]
    public async Task<ActionResult<Category>> AddCategory([FromBody] string name)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            return BadRequest("Category name cannot be empty.");
        }

        var category = new Category { Name = name };
        _context.Categories.Add(category);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetCategoryById), new { id = category.Id }, category);
    }

    // PUT: api/Categories/5
    // This endpoint updates the name of the category with the given ID.
    [HttpPut("{id}")]
    [Authorize(Roles = "Admin,Employee")]
    public async Task<IActionResult> UpdateCategory(int id, [FromBody] string name)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            return BadRequest("Category name cannot be empty.");
        }

        var category = await _context.Categories.FindAsync(id);
        if (category == null)
        {
            return NotFound("Category not found.");
        }

        category.Name = name;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    // GET: api/Categories/5
    // This endpoint retrieves a category by its ID.
    [HttpGet("{id}")]
    [Authorize(Roles = "Admin,Employee,User")]
    public async Task<ActionResult<Category>> GetCategoryById(int id)
    {
        var category = await _context.Categories.FindAsync(id);
        if (category == null)
        {
            return NotFound();
        }

        return category;
    }
}
