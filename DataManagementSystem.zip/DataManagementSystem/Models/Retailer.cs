﻿namespace DataManagementSystem.Models
{
    // Represents a retailer in the database.
    // A retailer is an entity that can have multiple items associated with it.
    public class Retailer
    {
        // Unique identifier for the retailer.
        // Typically used as the primary key in the database.
        public int Id { get; set; }

        // Name of the retailer.
        // This should be descriptive and help users identify the retailer.
        public string Name { get; set; }

        // Additional attributes can be added here.
        // For example, you might want to include address, contact information, etc.
        // public string Address { get; set; }
        // public string ContactNumber { get; set; }
        // etc.

        // Navigation property for related items.
        // This establishes a one-to-many relationship with the Item model,
        // meaning each retailer can have multiple items associated with it.
        public ICollection<Item> Items { get; set; }

        // Additional fields and relationships to other entities can be defined here.
        // For instance, you might add relationships to orders, reviews, or user ratings.
    }
}
