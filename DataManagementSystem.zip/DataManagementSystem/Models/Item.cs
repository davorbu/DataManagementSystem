﻿namespace DataManagementSystem.Models
{
    // Represents an item in the database.
    // Each item is associated with a retailer and a category.
    public class Item
    {
        // Unique identifier for the item.
        // Typically used as the primary key in the database.
        public int Id { get; set; }

        // Name of the item.
        // This should be descriptive and help users identify the item.
        public string Name { get; set; }

        // Description of the item.
        // Provides more details about the item, such as features or specifications.
        public string Description { get; set; }

        // Price of the item.
        // Represented as a decimal to accommodate fractional values, like cents.

        public decimal Price { get; set; }

        // URL of the item's image.
        // This is typically a link to where the image is stored (local path or URL).
        public string ImageUrl { get; set; }

        // Foreign key for the Retailer.
        // Links the item to its respective retailer.
        public int RetailerId { get; set; }
        // Navigation property for the Retailer.
        // Enables navigation from an item to its associated retailer.
        public Retailer Retailer { get; set; }

        // Foreign key for the Category.
        // Links the item to its respective category.
        public int CategoryId { get; set; }
        // Navigation property for the Category.
        // Enables navigation from an item to its associated category.
        public Category Category { get; set; }

        // Additional properties and relationships can be added here.
        // For example, stock quantity, dimensions, weight, etc.
    }
}
