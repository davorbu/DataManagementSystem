﻿namespace DataManagementSystem.Models
{
    // Represents a category in the database.
    // Each category can have multiple items associated with it.
    public class Category
    {
        // The unique identifier for the category.
        // This is usually set as the primary key in the database.
        public int Id { get; set; }

        // The name of the category.
        // This should be descriptive and concise.
        public string Name { get; set; }

        // Additional attributes for the category can be added here.
        // For example, you might want to add a Description field.

        // Navigation property for related items.
        // This establishes a one-to-many relationship with the Item model,
        // meaning each category can have multiple items associated with it.
        public ICollection<Item> Items { get; set; }

        // Additional fields and relationships to other entities can be defined here.
        // For example, you might add a ParentCategoryId for hierarchical category structures.
    }
}
