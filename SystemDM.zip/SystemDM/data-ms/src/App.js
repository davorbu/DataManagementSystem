import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import NavBar from './components/NavBar';
import Login from './components/Login';
import Retailers from './components/Retailers';
import Categories from './components/Categories';
import Items from './components/Items'; 
import Users from './components/Users';
import Home from './components/Home';

function App() {
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('user')));

  useEffect(() => {
    const handleStorageChange = () => {
      setUser(JSON.parse(localStorage.getItem('user')));
    };

    window.addEventListener('storage', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  const handleLoginSuccess = (userData) => {
    localStorage.setItem('user', JSON.stringify(userData));
    setUser(userData);
  };

  const handleLogout = () => {
    localStorage.removeItem('user');
    setUser(null);
  };

  return (
    <Router>
      <NavBar user={user} onLogout={handleLogout} />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={!user ? <Login onLoginSuccess={handleLoginSuccess} /> : <Navigate replace to="/" />} />
        <Route path="/retailers" element={user ? <Retailers token={user.token} /> : <Navigate replace to="/login" />} />
        <Route path="/categories" element={user ? <Categories token={user.token} /> : <Navigate replace to="/login" />} />
        <Route path="/items" element={user ? <Items token={user.token} /> : <Navigate replace to="/login" />} />
        <Route path="/users" element={user && user.role === 'Admin' ? <Users token={user.token} /> : <Navigate replace to="/login" />} />
      </Routes>
    </Router>
  );
}

export default App;
