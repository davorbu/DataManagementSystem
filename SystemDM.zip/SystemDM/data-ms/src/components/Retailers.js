import React, { useState, useEffect } from 'react';
import axios from 'axios';
import RetailerList from './RetailerList';
import AddRetailerForm from './AddRetailerForm';
import { Container, Typography } from '@mui/material';

const Retailers = ({ token }) => {
  const [retailers, setRetailers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchRetailers = async () => {
      try {
        const response = await axios.get('https://localhost:7132/api/Retailers', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setRetailers(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching retailers:', error);
        setError('Failed to fetch retailers');
        setLoading(false);
      }
    };

    fetchRetailers();
  }, [token]);

  const addRetailer = async (name) => {
    try {
      const response = await axios.post('https://localhost:7132/api/Retailers', { name }, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setRetailers([...retailers, response.data]); // Add a new merchant to the list
    } catch (error) {
      console.error('Error adding retailer:', error);
      setError('Failed to add retailer');
    }
  };

  return (
    <Container>
      <Typography variant="h4" component="h1" gutterBottom>
        Retailers Management
      </Typography>
      {loading && <Typography>Loading...</Typography>}
      {error && <Typography color="error">{error}</Typography>}
      {!loading && !error && (
        <>
          <AddRetailerForm addRetailer={addRetailer} />
          <RetailerList retailers={retailers} />
        </>
      )}
    </Container>
  );
};

export default Retailers;
