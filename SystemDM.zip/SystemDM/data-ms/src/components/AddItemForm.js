import React, { useState } from 'react';
import { TextField, Button, Paper, Box } from '@mui/material';

const AddItemForm = ({ onAddItem }) => {
  const [newItem, setNewItem] = useState({
    name: '',
    description: '',
    price: '',
  });

  const handleSubmit = (event) => {
    event.preventDefault();
    onAddItem(newItem);
    setNewItem({ name: '', description: '', price: '' });
  };

  return (
    <Paper style={{ padding: '16px', margin: '16px 0' }}>
      <form onSubmit={handleSubmit}>
        <Box display="flex" flexDirection="column" gap={2}>
          <TextField
            label="Name"
            value={newItem.name}
            onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
            required
          />
          <TextField
            label="Description"
            value={newItem.description}
            onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
            required
          />
          <TextField
            label="Price"
            value={newItem.price}
            onChange={(e) => setNewItem({ ...newItem, price: e.target.value })}
            required
          />
          <Button type="submit" color="primary">
            Add Item
          </Button>
        </Box>
      </form>
    </Paper>
  );
};

export default AddItemForm;
