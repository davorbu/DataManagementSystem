import React from 'react';
import { List, ListItem, ListItemText } from '@mui/material';

const RetailerList = ({ retailers }) => {
  return (
    <List>
      {retailers.map((retailer) => (
        <ListItem key={retailer.id}>
          <ListItemText primary={retailer.name} />
          {/* Dodajte ovdje dodatne akcije ako je potrebno */}
        </ListItem>
      ))}
    </List>
  );
};

export default RetailerList;
