// src/components/Home.js

import React from 'react';

const Home = () => {
  return (
    <div style={{ padding: "20px" }}>
      <h1>Welcome to the CMS Dashboard</h1>
      <p>This is the home page of your CMS. Use the navigation bar to access different sections.</p>
      {/* Ovdje možete dodati dodatne widgete ili informacije koje su relevantne za korisnike */}
    </div>
  );
};

export default Home;
