// src/components/NavBar.js

import React from 'react';
import { Link } from 'react-router-dom';
import { AppBar, Toolbar, Typography, Button, IconButton } from '@mui/material';
import PowerSettingsNewIcon from '@mui/icons-material/PowerSettingsNew';

const NavBar = ({ user, onLogout }) => {
  return (
    <AppBar position="static">
      <Toolbar>
        <Typography variant="h6" style={{ flexGrow: 1 }}>
          CMS Dashboard
        </Typography>
        {user && (
          <>
            <Button color="inherit" component={Link} to="/">
              Home
            </Button>
            <Button color="inherit" component={Link} to="/retailers">
              Retailers
            </Button>
            <Button color="inherit" component={Link} to="/categories">
              Categories
            </Button>
            <Button color="inherit" component={Link} to="/items">
              Items
            </Button>
            {user.role === "Admin" && (
              <Button color="inherit" component={Link} to="/users">
                Users
              </Button>
            )}
            <IconButton color="inherit" onClick={onLogout}>
              <PowerSettingsNewIcon />
            </IconButton>
          </>
        )}
        {!user && (
          <Button color="inherit" component={Link} to="/login">
            Login
          </Button>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default NavBar;
