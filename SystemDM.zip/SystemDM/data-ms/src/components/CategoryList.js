// components/CategoryList.js
import React, { useState } from "react";

const CategoryList = ({ categories, updateCategory, deleteCategory }) => {
  const [editId, setEditId] = useState(null);
  const [newName, setNewName] = useState("");

  const handleEdit = (category) => {
    setEditId(category.id);
    setNewName(category.name);
  };

  const handleUpdate = () => {
    updateCategory(editId, newName);
    setEditId(null);
    setNewName("");
  };

  const handleCancel = () => {
    setEditId(null);
    setNewName("");
  };

  return (
    <ul>
      {categories.map((category) => (
        <li key={category.id}>
          {editId === category.id ? (
            <>
              <input
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
              />
              <button onClick={handleUpdate}>Save</button>
              <button onClick={handleCancel}>Cancel</button>
            </>
          ) : (
            <>
              {category.name}
              <button onClick={() => handleEdit(category)}>Edit</button>
              <button onClick={() => deleteCategory(category.id)}>
                Delete
              </button>
            </>
          )}
        </li>
      ))}
    </ul>
  );
};

export default CategoryList;
