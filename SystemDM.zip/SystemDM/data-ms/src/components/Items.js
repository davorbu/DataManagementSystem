import React, { useState, useEffect } from 'react';
import axios from 'axios';
import AddItemForm from './AddItemForm';
import ItemList from './ItemList';
import { Container, Typography, Button, CircularProgress } from '@mui/material';

const Items = ({ token }) => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const response = await axios.get('https://localhost:7132/api/Items', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setItems(response.data);
      } catch (error) {
        console.error('Error fetching items:', error);
        setError('Failed to fetch items');
      } finally {
        setLoading(false);
      }
    };

    fetchItems();
  }, [token]);

  const handleAddItem = async (newItem) => {
    try {
      const response = await axios.post('https://localhost:7132/api/Items', newItem, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setItems([...items, response.data]);
    } catch (error) {
      console.error('Error adding new item:', error);
      setError('Failed to add item');
    }
  };

  const handleEditItem = async (item) => {
    try {
      await axios.put(`https://localhost:7132/api/Items/${item.id}`, item, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setItems(items.map(i => i.id === item.id ? item : i));
    } catch (error) {
      console.error('Error updating item:', error);
      setError('Failed to update item');
    }
  };

  const handleDeleteItem = async (itemId) => {
    try {
      await axios.delete(`https://localhost:7132/api/Items/${itemId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setItems(items.filter(i => i.id !== itemId));
    } catch (error) {
      console.error('Error deleting item:', error);
      setError('Failed to delete item');
    }
  };

  return (
    <Container>
      <Typography variant="h4" component="h1" gutterBottom>
        Items Management
      </Typography>
      <AddItemForm onAddItem={handleAddItem} />
      {loading ? (
        <CircularProgress />
      ) : error ? (
        <Typography color="error">{error}</Typography>
      ) : (
        <ItemList items={items} onEdit={handleEditItem} onDelete={handleDeleteItem} />
      )}
    </Container>
  );
};

export default Items;
