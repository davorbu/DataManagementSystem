import React, { useState, useEffect } from 'react';
import axios from 'axios';
import CategoryList from './CategoryList';
import AddCategoryForm from './AddCategoryForm';
import { Container, Typography, Box, Paper, Grid } from '@mui/material';

const Categories = ({ token }) => {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await axios.get(
          'https://localhost:7132/api/Categories',
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        setCategories(response.data);
      } catch (error) {
        console.error('Error fetching categories:', error);
      }
    };

    fetchCategories();
  }, [token]);

  const addCategory = async (categoryName) => {
    try {
      const response = await axios.post(
        'https://localhost:7132/api/Categories',
        { name: categoryName },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setCategories([...categories, response.data]);
    } catch (error) {
      console.error('Error adding category:', error);
    }
  };

  const updateCategory = async (id, newName) => {
    try {
      await axios.put(
        `https://localhost:7132/api/Categories/${id}`,
        { name: newName },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setCategories(
        categories.map((category) =>
          category.id === id ? { ...category, name: newName } : category
        )
      );
    } catch (error) {
      console.error('Error updating category:', error);
    }
  };

  const deleteCategory = async (id) => {
    try {
      await axios.delete(`https://localhost:7132/api/Categories/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCategories(categories.filter((category) => category.id !== id));
    } catch (error) {
      console.error('Error deleting category:', error);
    }
  };

  return (
    <Container maxWidth="md">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Category Management
        </Typography>
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <AddCategoryForm addCategory={addCategory} />
          </Grid>
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 2, minHeight: 200 }}>
              <CategoryList
                categories={categories}
                updateCategory={updateCategory}
                deleteCategory={deleteCategory}
              />
            </Paper>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
};

export default Categories;
