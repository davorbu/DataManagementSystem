import React, { useState } from 'react';
import { Button, TextField, Paper, Box } from '@mui/material';

const AddRetailerForm = ({ addRetailer }) => {
  const [name, setName] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    addRetailer(name);
    setName('');
  };

  return (
    <Paper style={{ padding: '16px', margin: '16px 0' }}>
      <form onSubmit={handleSubmit}>
        <Box display="flex" alignItems="center">
          <TextField
            label="New Retailer Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <Button type="submit" color="primary" style={{ marginLeft: '8px' }}>
            Add Retailer
          </Button>
        </Box>
      </form>
    </Paper>
  );
};

export default AddRetailerForm;

